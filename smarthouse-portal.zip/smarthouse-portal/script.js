document.getElementById('clientForm').addEventListener('submit', function (e) {
  e.preventDefault();
  document.getElementById('formMessage').textContent = 'Thank you. Your intake has been recorded. Connect this form to Jotform, Fillout, HubSpot, or Google Forms for live submissions.';
  this.reset();
});
